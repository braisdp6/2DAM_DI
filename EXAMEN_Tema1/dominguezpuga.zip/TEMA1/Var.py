global ui
global calendarAlta
global calendarBaja
global ventanaSalir
global acercaDe
global dlgAbrir # Nota: Variable que abre las ventanas de Windows
global bbdd
version = "0.0.1rc"